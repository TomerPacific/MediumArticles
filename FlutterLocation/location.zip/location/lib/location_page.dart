import 'package:flutter/material.dart';


class LocationPage extends StatefulWidget {

  @override
  _LocationPageState createState() => _LocationPageState();

}


class _LocationPageState extends State<LocationPage> {

  void requestLocationPermission(BuildContext context) async {

  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Requesting Location Permission'),
      ),
      body:Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Padding(
                padding: const EdgeInsets.all(16.0),
                child: Center(
                  child: new Text(
                      "Requesting Location Permission...",
                      textAlign: TextAlign.center
                  ),
                )
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: RaisedButton(
                  onPressed: () {
                    requestLocationPermission(context);
                  },
                  child: Text('Get Location Permission'),
                  color: Colors.green
              ),
            ),
          ]
      ),
    );
  }

}